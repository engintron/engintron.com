Welcome to the Engintron wiki!

This is where we document how Engintron works as well as optimization guides for cPanel/WHM.

Looking for future development of Engintron? Have a look at the Development Roadmap: https://github.com/engintron/engintron/wiki/Engintron-Roadmap

Documents are organized in the following sections...

## MUST READ
* [Requirements](https://github.com/engintron/engintron/wiki/Requirements)

## GENERAL
* [Preface](https://github.com/engintron/engintron/wiki/01.-Preface)
* [Installation (and updates)](https://github.com/engintron/engintron/wiki/02.-Installation-(and-updates))
* [Uninstalling](https://github.com/engintron/engintron/wiki/03.-Uninstalling)
* [Using Engintron](https://github.com/engintron/engintron/wiki/04.-Using-Engintron)
* [Why is Engintron a better solution compared to other Nginx installers for cPanel](https://github.com/engintron/engintron/wiki/05.-Why-is-Engintron-a-better-solution-compared-to-other-Nginx-installers-for-cPanel)
* [FAQ](https://github.com/engintron/engintron/wiki/FAQ)
* [Changelog](https://github.com/engintron/engintron/wiki/Changelog)
* [Engintron Roadmap](https://github.com/engintron/engintron/wiki/Engintron-Roadmap)

## TROUBLESHOOTING
* ["Welcome to Nginx on Fedora" showing on all sites after upgrading Engintron or cPanel (aka Nginx from EPEL repo issue)
](https://github.com/engintron/engintron/wiki/%22Welcome-to-Nginx-on-Fedora%22-showing-on-all-sites-after-upgrading-Engintron-or-cPanel-(aka-Nginx-from-EPEL-repo-issue))
* [Check if visitor IPs are properly logged in Apache after installing Engintron](https://github.com/engintron/engintron/wiki/Check-if-visitor-IPs-are-properly-logged-in-Apache-after-installing-Engintron)
* [How to uninstall other Nginx plugins for cPanel (before installing Engintron)](https://github.com/engintron/engintron/wiki/How-to-uninstall-other-Nginx-plugins-for-cPanel-(before-installing-Engintron))
* [Fix "localhost could not be resolved" entries in your Nginx log files](https://github.com/engintron/engintron/wiki/Fix-%22localhost-could-not-be-resolved%22-entries-in-your-Nginx-log-files)
* [Fix "110: Connection timed out" errors appearing in Nginx logs](https://github.com/engintron/engintron/wiki/Fix-%22110:-Connection-timed-out%22-errors-appearing-in-Nginx-logs)
* [SSL certificate changes not visible in Nginx? Here's a possible explanation & solution](https://github.com/engintron/engintron/wiki/SSL-certificate-changes-not-visible-in-Nginx%3F-Here's-a-possible-explanation-&-solution)

## ADDITIONAL INFO, SETUP & GOTCHAS
* [About Engintron's micro caching features](https://github.com/engintron/engintron/wiki/About-Engintron's-micro-caching-features)
* [Engintron & the "Custom Rules" file (for Nginx)](https://github.com/engintron/engintron/wiki/Engintron-&-the-%22Custom-Rules%22-file-(for-Nginx))
* [Excluding specific domains or domain paths from micro caching](https://github.com/engintron/engintron/wiki/Excluding-specific-domains-or-domain-paths-from-micro-caching)
* [Engintron & CloudFlare](https://github.com/engintron/engintron/wiki/Engintron-&-CloudFlare)
* [Engintron & (under development) domains that don't yet resolve (point) to your cPanel server](https://github.com/engintron/engintron/wiki/Engintron-&-(under-development)-domains-that-don't-yet-resolve-(point)-to-your-cPanel-server)
* [Restrict access to ports 8080 & 8443 used by Apache only for Nginx](https://github.com/engintron/engintron/wiki/Restrict-access-to-ports-8080-&-8443-used-by-Apache-only-for-Nginx)
* [Change the location of Nginx cache & temp files](https://github.com/engintron/engintron/wiki/Change-the-location-of-Nginx-cache-&-temp-files)
* [Cron job to purge Nginx cache & temp files](https://github.com/engintron/engintron/wiki/Cron-job-to-purge-Nginx-cache-&-temp-files)
* [SSL certificate considerations with cPanel's AutoSSL](https://github.com/engintron/engintron/wiki/SSL-certificate-considerations-with-cPanel's-AutoSSL)
* [Enable IPv6 support in Nginx (for IPv6 capable servers)](https://github.com/engintron/engintron/wiki/Enable-IPv6-support-in-Nginx)
* [Redirect webmail.domain.tld from HTTP to HTTPS](https://github.com/engintron/engintron/wiki/Redirect-webmail.domain.tld-from-HTTP-to-HTTPS)

## BEYOND ENGINTRON - OPTIMIZATION GUIDES
* [cPanel WHM initial optimal setup](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-cPanel-WHM-initial-optimal-setup)
* [Optimizing MySQL](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-Optimizing-MySQL)
* [Install APC(u) in cPanel](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-Install-APC(u)-in-cPanel)
* [Install Memcached in cPanel (EasyApache 4 only)](https://github.com/engintron/engintron/wiki/Install-Memcached-in-cPanel-(EasyApache-4-only))
* [Optimizing Apache](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-Optimizing-Apache)
* [Optimizing PHP FastCGI (EasyApache 3 only)](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-Optimizing-PHP-FastCGI-(under-EasyApache-3))
* [Optimizing CentOS](https://github.com/engintron/engintron/wiki/Beyond-Engintron:-Optimizing-CentOS)

## EXTENDING ENGINTRON
* [3rd party scripts for Engintron](https://github.com/engintron/engintron/wiki/3rd-party-scripts-for-Engintron)

## USER CONTRIBUTED GUIDES
* [CentOS 6 and HTTP 2 ALPN support
](https://github.com/engintron/engintron/wiki/CentOS-6-and-HTTP-2-ALPN-support)
* [Offload HTTPS traffic to Nginx only
](https://github.com/engintron/engintron/wiki/Offload-HTTPS-traffic-to-Nginx-only)
* [How to log real visitor IP when using Engintron on cPanel/WHM](https://www.damchey.com/2018/01/how-to-log-real-visitor-ip-when-using-engintron-on-cpanel/) [this will probably be included in an upcoming release of Engintron]

**Thank you for using Engintron!**

_(updated November 2018)_